from frame import Frame
from mydevice import MyDevice
import time
import csv
import json


class UDSresponse(MyDevice):
    def __init__(self):
        super(UDSresponse, self).__init__()
        self.send_frame = []


    def overtest(self):
        # target_file_list = ['1n9', '6n14']
        target_file_list = ['1n9']
        for filename in target_file_list:
            read(filename=filename)
            sendframe(filename=filename)

    def read(self, filename=""):
        """ 将扫描出来的诊断ID 依次扫描 找出各诊断ID的服务的支持情况 """
        with open('./original/{}processed.csv'.format(filename), 'r', newline='') as csv_file:
            readers = csv.reader(csv_file)
            for read in readers:
                data_list = []
                send_frame = []
                new_list = eval(read[1])
                for i in new_list:
                    data_list.append(int(i, 16))
                send_frame.append(int(read[0], 16))
                send_frame.append(data_list)
                self.send_frame.append(send_frame)
        csv_file.close()

    def sendframe(self, filename=""):
        with open('./response/{}response.csv'.format(filename), 'w', newline='') as csv_file:
            writer = csv.writer(csv_file)
            for number in range(len(self.send_frame)):
                frame = self.send_frame[number]
                print(number)
                send_frame = Frame(arb_id=frame[0], data=frame[1])
                time0 = time.time()
                self.transmit(tx_frame=send_frame)
                while time.time() - time0 < 0.12:
                    data = self.receive()
                    if 0x700 <= data.ID <= 0x7ff:
                        p_list = []
                        for i in range(8):
                            p_list.append("0x" + "0" * (2 - len(hex(data.Data[i]).replace("0x", "")))
                                          + hex(data.Data[i]).replace("0x", ""))
                        writer.writerow([number+1, hex(data.ID), p_list])
        csv_file.close()


if __name__ == "__main__":
    UDSresponse = UDSresponse()
    UDSresponse.start(500)
    try:

        UDSresponse.overtest()
    except Exception as result:
        print("unknown error :%s" % result)

    finally:
        UDSresponse.stop()